#Conexión con la DB

import psycopg2 #instalalrla

import matplotlib.pyplot as plt #para graficar
import pandas as pd
import seaborn as sns
from datetime import datetime

conn = psycopg2.connect(database="Vuelos",
                        host="localhost",
                        user="postgres",
                        password="mika1631995",
                        port="5432")

#user y fijarte cual es la contraseña 
cursor = conn.cursor() #crear un cursor

query = """
    SELECT
        (SELECT COUNT(*) FROM bookings.tickets) AS num_tickets_vendidos,
        COUNT(DISTINCT t.ticket_no) AS num_tickets_abordados
    FROM bookings.tickets t
    JOIN bookings.boarding_passes bp ON t.ticket_no = bp.ticket_no
"""
cursor.execute(query)
#resultados de la ocnsulta
result = cursor.fetchone()

cursor.close()
conn.close()

num_tickets_vendidos = result[0]
num_tickets_abordados = result[1]


labels = ['Total Tickets Vendidos', 'Tickets Abordados']
values = [num_tickets_vendidos, num_tickets_abordados]
colors = ['blue', 'red']

plt.bar(labels, values, width=0.8, align='center')
plt.xlabel('Tipo de Tickets')
plt.ylabel('Cantidad')
plt.title('Comparación de Tickets Vendidos y Abordados')
plt.show()


